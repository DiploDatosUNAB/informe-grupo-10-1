Datos de desaparecidos durante la dictadura. 

En el paquete presentes:

https://diegokoz.github.io/presentes/index.html



Ejemplo: 
https://diegokoz.github.io/presentes/articles/vignette.html